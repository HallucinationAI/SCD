import torch
from torch import nn


class RatioEstimator(nn.Module):
    def __init__(self, ninputs, noutputs, activation, layers):
        super().__init__()

        input_dim = ninputs[0] + noutputs[0]
        layers = [input_dim] + layers
        self.net = []

        for d1, d2 in zip(layers[0:-1], layers[1:]):
            self.net.extend([nn.Linear(d1, d2), activation()])

        self.net.extend([nn.Linear(d2, 1)])
        self.net = nn.Sequential(*self.net)

    def log_ratio(self, thetas, xs):
        input_features = torch.cat([thetas, xs], dim=1)
        return self.net(input_features).sigmoid()

    def forward(self, thetas, xs):
        return self.log_ratio(thetas, xs)


class LossCriterion(nn.Module):
    def __init__(self, ratio_estimator):
        super().__init__()
        self.ratio_estimator = ratio_estimator
        self.loss_criterion = torch.nn.BCELoss()

    def forward(self, inputs, outputs):
        '''
                ratio(x, theta) = P(x, theta) / P(x)P(theta) = ydependent / yindependent
                numerator / denominator

                numerator is the assumption that, x and theta are highly dependent
                denominator is the assumption that, x and theta are not dependent

                ratio here promotes highly related x and thetas and demotes independency

        :param inputs:
        :param outputs:
        :return:
        '''

        y_dependent = self.ratio_estimator(inputs, outputs)

        batch_size = inputs.shape[0]

        ## independent P(xb) and P(thetab)
        '''
            To create independent samples, the authors just shuffle the original inputs and thetas
            which makes them independent from each other instead of resampling from the simulator
        '''

        random_indices = torch.randperm(batch_size)
        thetas_independent = inputs[random_indices]

        random_indices = torch.randperm(batch_size)
        xs_independent = outputs[random_indices]

        y_independent = self.ratio_estimator(thetas_independent, xs_independent)

        '''
            y is the label, and we are training by cross entropy method
            y=1 and its probability P(y=1 |x, theta) ~= P(x, theta)
            y=0 and ist probability P(y=0 |x, theta) ~= P(x) x P(theta)
        '''

        loss = self.loss_criterion(y_dependent, torch.ones([batch_size], device='cuda')) + \
               self.loss_criterion(y_independent, torch.zeros([batch_size], device='cuda'))

        return loss
